---
type: "Rights Access and Privacy"
title: "Rights, access and privacy"
description: "Record-level rights, access constraints and privacy boundaries."
resource: "https://www.gov.uk/government/publications/hm-land-registry-data/public-data"
generated: {"by": "process:hmlr-okf-builder", "at": "2026-07-29T09:19:47Z"}
status: "released"
sources: [{"id": "official-source", "resource": "https://www.gov.uk/government/publications/hm-land-registry-data/public-data"}]
---

# Rights, access and privacy

Rights, fees, authentication and reuse constraints are record-level. “Public”
or “free” never implies Open Government Licence coverage. Bespoke HMLR
licences and third-party Ordnance Survey, GeoPlace or Royal Mail rights can
apply.

The acquisition boundary forbids credentials, signed download links, personal
property results, user uploads and production bulk records.
